script = 'khmer'
font_name = 'NotoSansKhmer-Regular'
version = 1
