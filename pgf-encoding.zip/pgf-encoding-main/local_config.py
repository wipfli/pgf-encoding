script = 'myanmar'
font_name = 'NotoSansMyanmar-Regular'
version = 1
