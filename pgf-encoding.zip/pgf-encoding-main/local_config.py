script = 'gujarati'
font_name = 'NotoSansGujarati-Regular'
version = 1
