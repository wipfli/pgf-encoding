script = 'devanagari'
font_name = 'NotoSansDevanagari-Regular'
version = 1
